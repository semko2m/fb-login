<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">

                    <h2><?php echo e(Auth::user()->name); ?></h2>
                    <?php if(Auth::user()->is_active): ?>
                        <p style="background: green; color: white">active in database</p>
                    <?php else: ?>
                        <p style="background: red; color: white">Not active in database</p>
                    <?php endif; ?>
                    <img src="<?php echo e(Auth::user()->avatar); ?>" alt="useravatar" class="avatar">

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>